import streamlit as st


def show_home():
    st.title("Home")